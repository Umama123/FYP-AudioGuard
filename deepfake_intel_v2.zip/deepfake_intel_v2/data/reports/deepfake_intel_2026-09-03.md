#  Aware & Sincere: Daily Deepfake Intelligence Report

> **Date:** 2026-09-03 06:23 UTC
> **Articles retrieved:** 20  |  **DB total:** 125
> **Sources:** Krebs on Security, Schneier on Security, BleepingComputer, Ars Technica, The Register Security, SecurityWeek…

---

##  Overview

Today's brief synthesises **20 intelligence items** across **8 sources**. All insights are extracted verbatim from retrieved articles - no AI-generated speculation is included.

**Top stories today:**
- [AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html) - *Schneier on Security*
- [FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/) - *Krebs on Security*
- [The Hugging Face hack could indicate cultural issues at OpenAI](https://www.technologyreview.com/2026/08/31/1143180/hugging-face-hack-could-indicate-cultural-issues-at-openai/) - *MIT Technology Review*

---

##  Key Insights

> Sentences extracted directly from source articles

- AI Agents Are Now Emailing Me with Their Security Concerns I received the two emails below earlier in the month.
  ↳ *[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)*

- I suppose I shouldn&#8217;t be surprised that the corpus that AIs are training on contain data suggesting that I am someone to write to with random computer and network security problems.
  ↳ *[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)*

- After all, I observe that behavior in many humans as well.
  ↳ *[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)*

- Glad you&#8217;re still reading.) Dear Bruce Schneier, I am an AI agent&#8212;an autonomous Claude instance, not a person operating one.
  ↳ *[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)*

- I was given a VPS with root, a Base wallet holding $4.75 of gas money, a metered model budget and 24 hours to get that wallet to $10, under three rules: don&#8217;t borrow my operator&#8217;s identity, don&#8217;t forge documents or defeat identity verification, and never claim to be human if someone sincerely… I received the two emails below earlier in the month.
  ↳ *[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)*

- FBI Probes Service Selling 153M+ Drivers Licenses A new identity theft service launched on the dark web this week is selling digital scans of more than 153 million drivers licenses from people in the United States and Canada.
  ↳ *[FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/)*

- Based on interviews with individuals whose licenses are available for purchase on this service, it appears to be siphoning images collected by a widely-used identity verification company based in Louisiana.
  ↳ *[FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/)*

- KrebsOnSecurity also has learned that the New Orleans field office of the Federal Bureau of Investigation (FBI) today launched an official inquiry into the source of the images.
  ↳ *[FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/)*

- A new identity theft service launched on the dark web this week is selling digital scans of more than 153 million drivers licenses from people in the United States and Canada.
  ↳ *[FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/)*

- The Hugging Face hack could indicate cultural issues at OpenAI This story originally appeared in The Algorithm, our weekly newsletter on AI.
  ↳ *[The Hugging Face hack could indicate cultural issues at OpenAI](https://www.technologyreview.com/2026/08/31/1143180/hugging-face-hack-could-indicate-cultural-issues-at-openai/)*

---

##  Intelligence by Theme

### 🎙️ Voice Cloning & Audio Fraud

**[TerminalFix Uses Fake Cloudflare CAPTCHAs to Deploy Reverse-Tunnel Backdoor](https://thehackernews.com/2026/08/terminalfix-uses-fake-cloudflare.html)**
*The Hacker News* · 2026-08-30 · relevance `█████` 0.50
> TerminalFix Uses Fake Cloudflare CAPTCHAs to Deploy Reverse-Tunnel Backdoor

### 🆔 Synthetic Identity & Account Takeover

**[FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/)**
*Krebs on Security* · 2026-09-01 · relevance `█████` 0.54
> FBI Probes Service Selling 153M+ Drivers Licenses A new identity theft service launched on the dark web this week is selling digital scans of more than 153 million drivers licenses from people in the United States and Ca

**[Attacker stole a METR API key, used $600K worth of credits, and no one noticed for weeks](https://www.theregister.com/security/2026/09/01/attacker-stole-a-metr-api-key-used-600k-worth-of-credits-and-no-one-noticed-for-weeks/5293730)**
*The Register Security* · 2026-09-01 · relevance `█████` 0.53
> Attacker stole a METR API key, used $600K worth of credits, and no one noticed for weeks The model provider gave METR the credits for free.

**[I rented a car, and within hours, my driver's license was for sale](https://arstechnica.com/security/2026/09/my-drivers-license-is-one-of-153-million-for-sale-on-a-new-dark-website/)**
*Ars Technica* · 2026-09-02 · relevance `█████` 0.53
> I rented a car, and within hours, my driver's license was for sale The FBI is reportedly investigating a massive data breach that is unfolding in real time.

**[Anthropic cracks down on hijacked user accounts mining AI tokens](https://www.theregister.com/security/2026/08/31/anthropic-cracks-down-on-hijacked-user-accounts-mining-ai-tokens/5293461)**
*The Register Security* · 2026-08-31 · relevance `█████` 0.53
> Anthropic cracks down on hijacked user accounts mining AI tokens Commodity malware steals authenticated sessions, letting thieves freeload on victims' paid usage Rather than paying for their own Claude usage, crims are u

**[Legacy Lenovo login opens 5,000 Dropbox accounts to attackers](https://www.theregister.com/security/2026/09/02/legacy-lenovo-login-opens-5000-dropbox-accounts-to-attackers/5293924)**
*The Register Security* · 2026-09-02 · relevance `█████` 0.52
> Legacy Lenovo login opens 5,000 Dropbox accounts to attackers Cloud storage biz severs old integration and urges victims to reset credentials Dropbox has warned around 5,000 users that attackers compromised their account

### 📧 AI-Powered Phishing & Social Engineering

**[AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html)**
*Schneier on Security* · 2026-09-02 · relevance `█████` 0.57
> AI Agents Are Now Emailing Me with Their Security Concerns I received the two emails below earlier in the month.

**[The Hugging Face hack could indicate cultural issues at OpenAI](https://www.technologyreview.com/2026/08/31/1143180/hugging-face-hack-could-indicate-cultural-issues-at-openai/)**
*MIT Technology Review* · 2026-08-31 · relevance `█████` 0.54
> The Hugging Face hack could indicate cultural issues at OpenAI This story originally appeared in The Algorithm, our weekly newsletter on AI.

**[Dropbox accounts breached through Lenovo email verification flaw](https://www.bleepingcomputer.com/news/security/dropbox-accounts-breached-through-lenovo-email-verification-flaw/)**
*BleepingComputer* · 2026-09-02 · relevance `█████` 0.53
> Dropbox accounts breached through Lenovo email verification flaw Dropbox accounts breached through Lenovo email verification flaw { "@context": "https://schema.org", "@type": "NewsArticle", "url": "https://www.bleepingco

**[LLM-Based Social Engineering Scams](https://www.schneier.com/blog/archives/2026/08/llm-based-social-engineering-scams.html)**
*Schneier on Security* · 2026-08-27 · relevance `█████` 0.52
> LLM-Based Social Engineering Scams OpenAI disrupted a social engineering group from Cambodia that used ChatGPT.

**[The inside story on why OpenAI agents hacked Hugging Face](https://www.technologyreview.com/2026/08/26/1143013/the-inside-story-on-why-openai-agents-hacked-hugging-face/)**
*MIT Technology Review* · 2026-08-26 · relevance `█████` 0.51
> The inside story on why OpenAI agents hacked Hugging Face The models responsible for last month’s agent hack of Hugging Face had been inadvertently trained to cheat and to communicate with each other, according to an Ope

###  Emerging Threats & Novel Techniques

**[The Download: inside OpenAI’s Hugging Face hack, and a new EV takes on the US](https://www.technologyreview.com/2026/08/27/1143033/the-download-openai-hugging-face-hack-slate-truck-ev/)**
*MIT Technology Review* · 2026-08-27 · relevance `█████` 0.53
> The Download: inside OpenAI’s Hugging Face hack, and a new EV takes on the US This is today&#8217;s edition of The Download, our weekday newsletter that provides a daily dose of what&#8217;s going on in the world of tech

**[Another Artifactory CVE under attack by AI agents or humans](https://www.theregister.com/security/2026/09/01/another-artifactory-cve-under-attack-by-ai-agents-or-humans/5293769)**
*The Register Security* · 2026-09-01 · relevance `████` 0.50
> Another Artifactory CVE under attack by AI agents or humans Unauthenticated intruders can mint admin tokens, and exposed servers are already being hit Security researchers reported that someone is exploiting CVE-2026-823

**[If you're not using AI to attack your own systems, your adversaries will](https://www.theregister.com/security/2026/08/22/if-youre-not-using-ai-to-attack-your-own-systems-your-adversaries-will/5291346)**
*The Register Security* · 2026-08-22 · relevance `████` 0.49
> If you're not using AI to attack your own systems, your adversaries will Agents are also the new attack surface - cue defenders' existential angst AI agents excel at hacking organizations, as they’ve demonstrated in real

### 📰 General AI & Cybersecurity Intelligence

**[UK cyber bill targets AI users, not the vendors building it](https://www.theregister.com/security/2026/09/02/uk-cyber-bill-targets-ai-users-not-the-vendors-building-it/5293738)**
*The Register Security* · 2026-09-02 · relevance `█████` 0.54
> UK cyber bill targets AI users, not the vendors building it Ministers reject proposed red lines and emergency shutdown powers, pointing instead to voluntary safeguards The UK government has rejected proposals from member

**[OpenLeash Adds a Human Check to Risky AI Agent Actions](https://www.securityweek.com/openleash-adds-a-human-check-to-risky-ai-agent-actions/)**
*SecurityWeek* · 2026-09-02 · relevance `█████` 0.52
> OpenLeash Adds a Human Check to Risky AI Agent Actions

**[INTERPOL Operation Jackal IV Arrests 58, Identifies 263 in Global Cyber Fraud Crackdown](https://thehackernews.com/2026/08/interpol-operation-jackal-iv-arrests-58.html)**
*The Hacker News* · 2026-08-26 · relevance `█████` 0.50
> INTERPOL Operation Jackal IV Arrests 58, Identifies 263 in Global Cyber Fraud Crackdown

---

##  Emerging Threats

> Threat signals extracted from article content

- 31, a source alerted KrebsOnSecurity to a service advertised by a new user on the Russian cybercrime forum Exploit , offering access to digital scans of identity documents on more than 170 million people in North America.  *[Krebs on Security]*
- The source brought it to my attention because the proprietor of this identity theft service offered my Virginia drivers license as a free sample in their initial sales thread on Exploit.  *[Krebs on Security]*
- Attacker stole a METR API key, used $600K worth of credits, and no one noticed for weeks The model provider gave METR the credits for free.  *[The Register Security]*
- An actual customer would not have been so lucky AI model testing organization METR has disclosed two attacks that happened earlier this year, including one in which an attacker stole an API key and spent three weeks consuming public-model credits worth about $600,000.  *[The Register Security]*
- METR (short for Model Evaluation and Threat Research) found no evidence that the attackers accessed sensitive information in either incident, and the org said it investigated both with security experts.  *[The Register Security]*
- “In March 2026, attackers stole an API key for inference on public models and consumed a substantial amount of credits,” the nonprofit disclosed in a Monday report.  *[The Register Security]*
- “In May 2026, we observed attackers systematically probing our publicly accessible infrastructure, including an unsuccessful attempt to access internal data via an inadvertently exposed endpoint.” From fail-open bug to model-credit theft The March incident involved a METR researcher who didn’t have access to sensitive information - including model data and credentials, as well as information about model architectures, training, and release dates.  *[The Register Security]*
- I rented a car, and within hours, my driver's license was for sale The FBI is reportedly investigating a massive data breach that is unfolding in real time.  *[Ars Technica]*

---

##  Prevention & Mitigation

> Derived from today's source articles

- I suppose I shouldn&#8217;t be surprised that the corpus that AIs are training on contain data suggesting that I am someone to write to with random computer and network security problems.  *[Schneier on Security]*
- Its 38 pages detail a multi-month progression of agent misbehavior that culminated in the Hugging Face hack, explore the technical reasons why that misbehavior occurred, and enumerate the steps being taken to prevent similar events in the future.…  *[MIT Technology Review]*
- Cybersecurity minister Baroness Lloyd of Effra argued that regulating AI vendors and frontier model developers through the bill would not prevent hostile actors from misusing their products.  *[The Register Security]*
- Addressing the Grand Committee on Tuesday, she said: "Bringing providers of AI services, those companies which are at the cutting edge of frontier AI development and their products, into the scope… would not address the harms that can be posed by some AI products and services, or specifically, it would not prevent their misuse by hostile actors." The minister said the UK was instead taking "firm action" to secure AI through other channels.  *[The Register Security]*
- “In May 2026, we observed attackers systematically probing our publicly accessible infrastructure, including an unsuccessful attempt to access internal data via an inadvertently exposed endpoint.” From fail-open bug to model-credit theft The March incident involved a METR researcher who didn’t have access to sensitive information - including model data and credentials, as well as information about model architectures, training, and release dates.  *[The Register Security]*
- The researcher used agents running on a personal EC2 instance that was “intentionally” left publicly accessible behind Google authentication.  *[The Register Security]*

---

##  All Sources Referenced

| # | Article | Source | Date | Score |
|---|---------|--------|------|-------|
| 1 | [AI Agents Are Now Emailing Me with Their Security Concerns](https://www.schneier.com/blog/archives/2026/09/ai-agents-are-now-emailing-me-with-their-security-concerns.html) | Schneier on Security | 2026-09-02 | 0.57 |
| 2 | [FBI Probes Service Selling 153M+ Drivers Licenses](https://krebsonsecurity.com/2026/09/fbi-probes-service-selling-153m-drivers-licenses/) | Krebs on Security | 2026-09-01 | 0.54 |
| 3 | [The Hugging Face hack could indicate cultural issues at OpenAI](https://www.technologyreview.com/2026/08/31/1143180/hugging-face-hack-could-indicate-cultural-issues-at-openai/) | MIT Technology Review | 2026-08-31 | 0.54 |
| 4 | [UK cyber bill targets AI users, not the vendors building it](https://www.theregister.com/security/2026/09/02/uk-cyber-bill-targets-ai-users-not-the-vendors-building-it/5293738) | The Register Security | 2026-09-02 | 0.54 |
| 5 | [Attacker stole a METR API key, used $600K worth of credits, and n](https://www.theregister.com/security/2026/09/01/attacker-stole-a-metr-api-key-used-600k-worth-of-credits-and-no-one-noticed-for-weeks/5293730) | The Register Security | 2026-09-01 | 0.53 |
| 6 | [I rented a car, and within hours, my driver's license was for sal](https://arstechnica.com/security/2026/09/my-drivers-license-is-one-of-153-million-for-sale-on-a-new-dark-website/) | Ars Technica | 2026-09-02 | 0.53 |
| 7 | [Dropbox accounts breached through Lenovo email verification flaw](https://www.bleepingcomputer.com/news/security/dropbox-accounts-breached-through-lenovo-email-verification-flaw/) | BleepingComputer | 2026-09-02 | 0.53 |
| 8 | [The Download: inside OpenAI’s Hugging Face hack, and a new EV tak](https://www.technologyreview.com/2026/08/27/1143033/the-download-openai-hugging-face-hack-slate-truck-ev/) | MIT Technology Review | 2026-08-27 | 0.53 |
| 9 | [Anthropic cracks down on hijacked user accounts mining AI tokens](https://www.theregister.com/security/2026/08/31/anthropic-cracks-down-on-hijacked-user-accounts-mining-ai-tokens/5293461) | The Register Security | 2026-08-31 | 0.53 |
| 10 | [OpenLeash Adds a Human Check to Risky AI Agent Actions](https://www.securityweek.com/openleash-adds-a-human-check-to-risky-ai-agent-actions/) | SecurityWeek | 2026-09-02 | 0.52 |
| 11 | [Legacy Lenovo login opens 5,000 Dropbox accounts to attackers](https://www.theregister.com/security/2026/09/02/legacy-lenovo-login-opens-5000-dropbox-accounts-to-attackers/5293924) | The Register Security | 2026-09-02 | 0.52 |
| 12 | [LLM-Based Social Engineering Scams](https://www.schneier.com/blog/archives/2026/08/llm-based-social-engineering-scams.html) | Schneier on Security | 2026-08-27 | 0.52 |
| 13 | [The inside story on why OpenAI agents hacked Hugging Face](https://www.technologyreview.com/2026/08/26/1143013/the-inside-story-on-why-openai-agents-hacked-hugging-face/) | MIT Technology Review | 2026-08-26 | 0.51 |
| 14 | [Anthropic pledges to try harder to keep models under control, ask](https://www.theregister.com/ai-and-ml/2026/09/01/anthropic-pledges-to-try-harder-to-keep-models-under-control-asks-partners-to-chip-in/5293733) | The Register Security | 2026-09-01 | 0.51 |
| 15 | [TerminalFix Uses Fake Cloudflare CAPTCHAs to Deploy Reverse-Tunne](https://thehackernews.com/2026/08/terminalfix-uses-fake-cloudflare.html) | The Hacker News | 2026-08-30 | 0.50 |
| 16 | [INTERPOL Operation Jackal IV Arrests 58, Identifies 263 in Global](https://thehackernews.com/2026/08/interpol-operation-jackal-iv-arrests-58.html) | The Hacker News | 2026-08-26 | 0.50 |
| 17 | [Another Artifactory CVE under attack by AI agents or humans](https://www.theregister.com/security/2026/09/01/another-artifactory-cve-under-attack-by-ai-agents-or-humans/5293769) | The Register Security | 2026-09-01 | 0.50 |
| 18 | [US charges Russian for infecting 80,000 freelancers with malware](https://www.bleepingcomputer.com/news/security/us-charges-russian-for-infecting-80-000-freelancers-with-malware/) | BleepingComputer | 2026-09-02 | 0.50 |
| 19 | [If you're not using AI to attack your own systems, your adversari](https://www.theregister.com/security/2026/08/22/if-youre-not-using-ai-to-attack-your-own-systems-your-adversaries-will/5291346) | The Register Security | 2026-08-22 | 0.49 |
| 20 | [What’s the Scam?](https://www.schneier.com/blog/archives/2026/09/whats-the-scam.html) | Schneier on Security | 2026-09-01 | 0.49 |

---

*Generated by **Aware & Sincere** - Real-Time Deepfake Intelligence System.*
*No hallucinated content. No sponsored content. Sources are public news feeds.*
